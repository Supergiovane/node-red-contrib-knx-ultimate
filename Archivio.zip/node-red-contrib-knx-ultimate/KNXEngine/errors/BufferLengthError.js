

class BufferLengthError extends Error {
}
exports.BufferLengthError = BufferLengthError;
