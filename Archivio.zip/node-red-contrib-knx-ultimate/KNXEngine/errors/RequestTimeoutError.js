class RequestTimeoutError extends Error {
}
exports.RequestTimeoutError = RequestTimeoutError;
