
class NotImplementedError extends Error {
}
exports.NotImplementedError = NotImplementedError;
//# sourceMappingURL=NotImplementedError.js.map