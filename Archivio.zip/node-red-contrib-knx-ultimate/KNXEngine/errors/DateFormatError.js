
class DateFormatError extends Error {
}
exports.DateFormatError = DateFormatError;
//# sourceMappingURL=DateFormatError.js.map