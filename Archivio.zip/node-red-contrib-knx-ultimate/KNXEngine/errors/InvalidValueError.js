
class InvalidValueError extends Error {
}
exports.InvalidValueError = InvalidValueError;
//# sourceMappingURL=InvalidValueError.js.map