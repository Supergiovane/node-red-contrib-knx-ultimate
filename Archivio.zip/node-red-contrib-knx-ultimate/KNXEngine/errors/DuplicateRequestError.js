
class DuplicateRequestError extends Error {
}
exports.DuplicateRequestError = DuplicateRequestError;
//# sourceMappingURL=DuplicateRequestError.js.map